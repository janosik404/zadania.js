# Sprawdzian Grupa A - Zadanie 2: Przelicznik Odległości

## Cel zadania

Stwórz funkcję przeliczającą mile lądowe na kilometry.

## Wymagania

1.  W pliku `index.html` w sekcji `<head>` zdefiniuj funkcję o nazwie `mileNaKilometry(mile)`.
2.  Funkcja przyjmuje jeden argument (liczbę mil).
3.  Funkcja powinna **obliczyć** wynik według wzoru: `mile * 1.6`.
4.  Funkcja ma wypisać wynik na ekranie w pełnym zdaniu (użyj `document.write` wewnątrz funkcji): "[ilość] mil to [wynik] km.<br>".
5.  Zjedź do sekcji `<body>`. Znajdź element `<div id="wynik">`.
6.  Wewnątrz tego diva wstaw znacznik `<script>` i wywołaj funkcję dla 10 mil i dla 50 mil.
7.  **W stopce pliku HTML (w sekcji `<footer>`) wpisz swoje imię, nazwisko i klasę.**

## Wskazówki

- Użyj operatora mnożenia `*`.
- Pamiętaj o kropce w liczbach zmiennoprzecinkowych (1.6).
