# Sprawdzian Grupa A - Zadanie 6: Opłata Pocztowa

## Cel zadania

Stwórz funkcję obliczającą koszt przesyłki na podstawie jej wagi.

## Wymagania

1.  W pliku `index.html` w sekcji `<head>` zdefiniuj funkcję o nazwie `obliczOplate(waga)`.
2.  Przyjmuje ona wagę w kilogramach.
3.  Zasady:
    - Waga < 1 kg: Opłata 5 zł.
    - Waga od 1 kg do 5 kg: Opłata 10 zł.
    - Waga powyżej 5 kg: Opłata 20 zł.
4.  Funkcja zwraca (lub wyświetla używając `document.write` wewnątrz funkcji) komunikat: "Przesyłka o wadze [X] kg kosztuje [Y] zł.<br>".
5.  Zjedź do sekcji `<body>`. Znajdź element `<div id="cennik">`.
6.  Wewnątrz tego diva wstaw znacznik `<script>` i wywołaj funkcję dla wagi: 0.5 kg, 3 kg i 10 kg.
7.  **W stopce pliku HTML (w sekcji `<footer>`) wpisz swoje imię, nazwisko i klasę.**

## Wskazówki

- Użyj konstrukcji `if` ... `else if` ... `else`.
