# Sprawdzian Grupa A - Zadanie 4: Zasięg (Napraw Błąd)

## Cel zadania

Zidentyfikuj i napraw błąd związany z zasięgiem zmiennych (scope).

## Problem

Plik `index.html` zawiera kod, który nie działa. Funkcja `rejestrujBlad()` powinna zwiększać licznik błędów (`liczbaBledow`), ale licznik zawsze wynosi 1 i nie sumuje się.

## Zadanie

1.  Przeanalizuj kod w `index.html`.
2.  Znajdź przyczynę, dlaczego `liczbaBledow` się resetuje.
3.  W sekcji `<head>` zmień kod tak, aby variable `liczbaBledow` była **zmienną globalną**, a funkcja tylko ją modyfikowała (nadal używając `document.write` i znacznika `<br>`).
4.  Zjedź do sekcji `<body>`. Znajdź element `<div id="wynik">`.
5.  Wewnątrz tego diva wstaw znacznik `<script>` i wywołaj naprawioną funkcję 3 razy.
6.  Wynik powinien być: "Liczba błędów: 1", "Liczba błędów: 2", "Liczba błędów: 3" (każde w nowej linii).
7.  **W stopce pliku HTML (w sekcji `<footer>`) wpisz swoje imię, nazwisko i klasę.**

## Wskazówki

- Gdzie jest zadeklarowana zmienna (`let`)? Wewnątrz czy na zewnątrz funkcji?
