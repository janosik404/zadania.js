# Sprawdzian Grupa A - Zadanie 3: Ocena Zaliczenia

## Cel zadania

Stwórz funkcję decyzyjną, która ocenia wynik egzaminu.

## Wymagania

1.  W pliku `index.html` w sekcji `<head>` zdefiniuj funkcję o nazwie `czyZdal(punkty)`.
2.  Przyjmuje ona liczbę punktów.
3.  Zasada: Aby zdać, trzeba mieć co najmniej 50 punktów.
4.  Jeśli `punkty >= 50`, funkcja wypisuje "Zdałeś!<br>" (użyj `document.write`).
5.  W przeciwnym razie funkcja wypisuje "Poprawka.<br>" (użyj `document.write`).
6.  Zjedź do sekcji `<body>`. Znajdź element `<div id="wynik">`.
7.  Wewnątrz tego diva wstaw znacznik `<script>` i wywołaj funkcję dla 40 punktów i dla 75 punktów.
8.  **W stopce pliku HTML (w sekcji `<footer>`) wpisz swoje imię, nazwisko i klasę.**

## Wskazówki

- Użyj instrukcji `if` oraz `else`.
