# Sprawdzian Grupa A - Zadanie 5: Generator Listy

## Cel zadania

Stwórz funkcję, która generuje listę wypunktowaną w HTML przy użyciu pętli.

## Wymagania

1.  W pliku `index.html` w sekcji `<head>` zdefiniuj funkcję o nazwie `generujListe(iloscElementow)`.
2.  Argument `iloscElementow` określa, ile punktów ma mieć lista.
3.  Funkcja powinna rozpocząć od wypisania znacznika otwierającego `<ul>` (używając `document.write` wewnątrz funkcji).
4.  Następnie, używając pętli `for` (od 1 do `iloscElementow`), powinna wypisywać elementy listy: `<li>Element nr X</li>`, gdzie X to numer obrotu pętli (używając `document.write`).
5.  Na koniec funkcja powinna wypisać znacznik zamykający `</ul>` (używając `document.write`).
6.  Zjedź do sekcji `<body>`. Znajdź element `<div id="lista">`.
7.  Wewnątrz tego diva wstaw znacznik `<script>` i wywołaj funkcję dla 5 elementów.
8.  **W stopce pliku HTML (w sekcji `<footer>`) wpisz swoje imię, nazwisko i klasę.**

## Wskazówki

- Pamiętaj, że `document.write` dokłada kod HTML do strony.
- Zmienna licznika w pętli (np. `i`) może posłużyć do numerowania elementów.
