# Sprawdzian Grupa A - Zadanie 7: Formularz Kontaktowy

## Cel zadania

Stwórz funkcję obsługującą symulację wysyłki formularza.

## Wymagania

1.  W pliku `index.html` w sekcji `<head>` zdefiniuj funkcję o nazwie `wyslijWiadomosc(imie, email, temat)`.
2.  Funkcja sprawdza, czy pola nie są puste (możesz założyć, że jeśli argument to pusty napis `""`, to pole jest puste).
3.  Jeśli któreś pole jest puste -> wyświetl błąd "Uzupełnij wszystkie dane!<br>" (używając `document.write`).
4.  Jeśli wszystkie dane są ok -> wyświetl sformatowane potwierdzenie (używając `document.write`):
    > "Dziękujemy, [imie]!<br>Wysłano wiadomość na temat: [temat].<br>Potwierdzenie na: [email].<br>"
5.  Zjedź do sekcji `<body>`. Znajdź element `<div id="status">`.
6.  Wewnątrz tego diva wstaw znacznik `<script>` i wywołaj funkcję dwa razy: raz poprawnie (z danymi), a raz z pustym ciągiem znaków (z błędem).
7.  **W stopce pliku HTML (w sekcji `<footer>`) wpisz swoje imię, nazwisko i klasę.**

## Wskazówki

- Użyj operatora `&&` lub zagnieżdżonych `if`.
- Pamiętaj że pusty tekst to `""`.
