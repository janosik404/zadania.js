# Sprawdzian Grupa A - Zadanie 1: Powitanie

## Cel zadania

Stwórz funkcję, która wyświetla spersonalizowane powitanie dla klienta sklepu.

## Wymagania

1.  W pliku `index.html` w sekcji `<head>` zdefiniuj funkcję `powitanieKlienta(imie)`.
2.  Przyjmuje ona jeden argument: `imie` (np. "Anna").
3.  Funkcja **nie zwraca** wartości, a jedynie wyświetla komunikat (użyj `document.write` wewnątrz funkcji) w formacie:
    "<h1>Witamy w naszym sklepie, [imie]!</h1>"
4.  Zjedź do sekcji `<body>`. Znajdź element `<div id="wynik">`.
5.  Wewnątrz tego diva wstaw znacznik `<script>` i wywołaj funkcję dla dwóch różnych imion.
6.  **W stopce pliku HTML (w sekcji `<footer>`) wpisz swoje imię, nazwisko i klasę.**

## Wskazówki

- Pamiętaj o cudzysłowach przy podawaniu argumentu (tekstu).
- Możesz użyć znacznika `<h1>` wewnątrz stringa w `document.write`.
